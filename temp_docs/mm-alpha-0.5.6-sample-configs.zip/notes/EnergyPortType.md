# Energy Port Type

## Recipe Ingredient

```json
{
  "type": "mm:energy",
  "amount": 1000
}
```

## Port Config

```json
{
  "maxReceive": 300,
  "maxExtract": 300,
  "capacity": 100000
}
```