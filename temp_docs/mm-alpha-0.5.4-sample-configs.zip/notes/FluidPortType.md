# Fluid Port Type

## Recipe Ingredient

```json
{
  "type": "mm:fluid",
  "fluid": "minecraft:water",
  "amount": 1000
}
```

## Port Config

```json
{
  "rows": 3,
  "columns": 3,
  "slotCapacity": 100000
}
```