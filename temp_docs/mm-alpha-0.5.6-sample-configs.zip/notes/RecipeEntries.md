# Recipe Entries

### Input Entries

```json
{
  "type": "mm:output/simple",
  "chance": 0.2, // Not required - Defaulted to 1
  "per_tick": true, // Nor Required - Defaulted to false
  "ingredient": {
    ...
  }
}
```

### Output Entries

```json
{
  "type": "mm:input/consume",
  "chance": 0.2, // Not required - Defaulted to 1
  "per_tick": true, // Nor Required - Defaulted to false
  "ingredient": {
    ...
  }
}
```