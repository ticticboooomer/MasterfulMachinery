# Fluid Port Type

## Recipe Ingredient

```json
{
  "type": "mm:item",
  "item": "minecraft:nether_star",
  "count": 7
}
```

## Port Config

```json
{
  "rows": 3,
  "columns": 3
}
```