# Extra Blocks

### Circuit Block

```json
{
  "id": "my_circuit",
  "name": "My Circuit",
  "type": "mm:circuit"
}
```

### Gearbox Block

```json
{
  "id": "my_gears",
  "name": "My Gears",
  "type": "mm:gearbox"
}
```

### Vent Block

```json
{
  "id": "my_vent",
  "name": "My Vent",
  "type": "mm:vent"
}
```